getJasmineRequireObj().version = function() {
  return "<%= version %>";
};
